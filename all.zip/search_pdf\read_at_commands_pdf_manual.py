import PyPDF2
import re


def extract_at_commands(pdf_path):
    # Initialize dictionary to store AT+ commands and descriptions
    at_commands = {}

    # Open the PDF file
    with open(pdf_path, 'rb') as file:
        # Create PDF reader object
        pdf_reader = PyPDF2.PdfReader(file)

        # Get total number of pages
        num_pages = len(pdf_reader.pages)

        # Variable to store description text
        current_description = ""
        current_command = None

        # Pattern to match AT+ command headers
        # Matches "2.2. AT+XXX Description" format
        header_pattern = r'(\d+\.\d+\.\s+)(AT\+[A-Z]+)\s+(.+)'

        # Iterate through all pages
        for page_num in range(num_pages):
            # Extract text from page
            page = pdf_reader.pages[page_num]
            text = page.extract_text()

            # Split text into lines
            lines = text.split('\n')

            for line in lines:
                # Check if line matches command header pattern
                match = re.match(header_pattern, line.strip())

                if match:
                    # If we were building a description, save it
                    if current_command and current_description:
                        at_commands[current_command] = current_description.strip()

                    # Start new command
                    current_command = match.group(2)  # AT+XXX
                    current_description = match.group(3)  # Description
                elif current_command:
                    # Add to current description if we're in a command section
                    current_description += " " + line.strip()

        # Save the last command if exists
        if current_command and current_description:
            at_commands[current_command] = current_description.strip()

    return at_commands


def main():
    # Specify your PDF file path
    pdf_path = "CAT-M1/Quectel_BG95BG77BG600L_Series_AT_Commands_Manual_V2.0-2.pdf"  # Replace with your PDF file path

    try:
        # Extract commands
        commands_dict = extract_at_commands(pdf_path)

        # Print the results
        print("Extracted AT+ Commands:")
        for command, description in commands_dict.items():
            print(f"{command}: {description}")
            print("-" * 50)

        # Optional: Save to file
        with open("at_commands.txt", "w", encoding="utf-8") as f:
            for command, description in commands_dict.items():
                f.write(f"{command}: {description}\n")
                f.write("-" * 50 + "\n")

    except FileNotFoundError:
        print("PDF file not found. Please check the file path.")
    except Exception as e:
        print(f"An error occurred: {str(e)}")


if __name__ == "__main__":
    main()
