import webbrowser


def nordic_lte(event):
    webbrowser.open_new(r"https://infocenter.nordicsemi.com/index.jsp?topic=%2Fref_at_commands%2FREF%2Fat_commands"
                        r"%2Fnw_service%2Fcereg_read.html")


def twilio(event):
    webbrowser.open_new("https://www.twilio.com/docs/iot/supersim/works-with-super-sim/quectel-bg95#useful-at-commands")


def quectel_forums(event):
    webbrowser.open_new("https://forums.quectel.com/")


def qbg95(event):
    webbrowser.open_new("https://www.quectel.com/product/lte-bg95-m3/")


def tc1wwg(event):
    webbrowser.open_new("https://www.airgain.com/?s=NL-SW-LTE-TC1WWG")


def lte_books(event):
    webbrowser.open_new("M:/Books/LTE")


def nimbelink_tc1wwg(event):
    webbrowser.open_new("https://www.airgain.com/?s=NL-SW-LTE-TC1WWG")


def telit_tc1wwg(event):
    webbrowser.open_new("https://www.airgain.com/?s=NL-SW-LTE-TC1WWG")
